from os import path as os_path, listdir as os_listdir
from shutil import rmtree as rmtree
import hashlib

def md5Checksum(filename):
    if os_path.exists(filename):
        with open(filename, 'rb') as fh:
            m = hashlib.md5()
            while True:
                data = fh.read(8192)
                if not data:
                    break
                m.update(data)
            return m.hexdigest()
    else:
        return ""

for File in os_listdir("/usr/lib/enigma2/python/Plugins/Extensions"):
	file=File.lower()
	if file.find("panel") != -1 or file.find("feed") != -1 or file.find("unisia") != -1 or file.find("ersia") != -1 or file.find("olden") != -1 or file.find("venus") != -1 or file.find("backupflas") != -1 or file.find("dreamsat") != -1:
		rmtree("/usr/lib/enigma2/python/Plugins/Extensions/%s" % File, ignore_errors=True)

for File in os_listdir("/usr/lib/enigma2/python/Plugins/SystemPlugins"):
	file=File.lower()
	if file.find("panel") != -1 or file.find("feed") != -1 or file.find("unisia") != -1 or file.find("ersia") != -1 or file.find("olden") != -1 or file.find("venus") != -1 or file.find("backupflas") != -1 or file.find("dreamsat") != -1:
		rmtree("/usr/lib/enigma2/python/Plugins/SystemPlugins/%s" % File, ignore_errors=True)

if not os_path.exists("/var/lib/dpkg/info/enigma2-plugin-systemplugins-gutemine.md5sums"):
	if os_path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemineFeed"):
		rmtree("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemineFeed", ignore_errors=True)
	if os_path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemine"):
		rmtree("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemine", ignore_errors=True)
if os_path.exists("/usr/bin/gReboot"):
	rmtree("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemine", ignore_errors=True)
if os_path.exists("/var/lib/dpkg/info/enigma2.md5sums"):
	m=open("/var/lib/dpkg/info/enigma2.md5sums","r")
	line=m.readline()
	m5=md5Checksum("/usr/bin/enigma2-system-state")
	while line:
		line=m.readline()
		if line.find("usr/bin/enigma2-system-state") is not -1:
			sp=line.split()
			print(sp)
			if sp[0]!=m5:
				rmtree("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemine", ignore_errors=True)
	m.close()
if os_path.exists("/var/lib/dpkg/info/enigma2-plugin-systemplugins-gutemine.md5sums"):
	m=open("/var/lib/dpkg/info/enigma2-plugin-systemplugins-gutemine.md5sums","r")
	line=m.readline()
	m6=md5Checksum("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemine/__init__.py")
	m7=md5Checksum("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemine/plugin.py")
	while line:
		line=m.readline()
		if line.find("usr/lib/enigma2/python/Plugins/SystemPlugins/gutemine/__init__.py") is not -1:
			sp=line.split()
			print(sp)
			if sp[0]!=m6:
				rmtree("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemine", ignore_errors=True)
		if line.find("usr/lib/enigma2/python/Plugins/SystemPlugins/gutemine/plugin.py") is not -1:
			sp=line.split()
			print(sp)
			if sp[0]!=m7:
				rmtree("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemine", ignore_errors=True)
	m.close()
if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/MrBig"):
	rmtree("/usr/lib/enigma2/python/Plugins/Extensions/MrBig", ignore_errors=True)
